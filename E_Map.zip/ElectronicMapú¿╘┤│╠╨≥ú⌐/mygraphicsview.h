#ifndef MYGRAPHICSVIEW_H
#define MYGRAPHICSVIEW_H
#include <QGraphicsView>
#include <QMouseEvent>

class MyGraphicsView : public QGraphicsView
{

//    Q_OBJECT
public:
    MyGraphicsView();
    qreal realscaling;
    qreal scalingOffset;
    bool flag_scaleChange;

protected:
    void wheelEvent(QWheelEvent *event) Q_DECL_OVERRIDE;
    void magnify();
    void shrink();
    void scaling(qreal scaleFactor);

signals:

};

#endif // MYGRAPHICSVIEW_H
